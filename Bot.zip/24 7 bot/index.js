const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http);
const mineflayer = require('mineflayer');
const crypto = require('crypto');
const path = require('path');

let bot;
const fixedPassword = 'MineBot123'; // You can change this

app.use(express.static('public'));
app.use(express.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public/index.html'));
});

app.post('/command', (req, res) => {
  const { cmd } = req.body;
  if (bot && bot.chat) {
    bot.chat(cmd);
    return res.send({ success: true, message: `Sent command: ${cmd}` });
  } else {
    return res.status(500).send({ success: false, message: 'Bot not connected' });
  }
});

io.on('connection', socket => {
  console.log('🔌 Client connected');

  socket.on('startBot', ({ host, port, username }) => {
    if (bot) bot.end(); // Disconnect existing bot

    bot = mineflayer.createBot({
      host,
      port: parseInt(port),
      username,
      version: false, // Auto detect version
    });

    bot.once('login', () => {
      console.log('✅ Bot logged in');
      socket.emit('status', 'Connected');

      // Anti-AFK: Jump every 60s
      setInterval(() => {
        bot.setControlState('jump', true);
        setTimeout(() => bot.setControlState('jump', false), 400);
      }, 60000);
    });

    bot.once('spawn', () => {
      // Auto register & login
      setTimeout(() => {
        bot.chat(`/register ${fixedPassword} ${fixedPassword}`);
        console.log('🔐 Sent register command');

        setTimeout(() => {
          bot.chat(`/login ${fixedPassword}`);
          console.log('🔓 Sent login command');
        }, 3000);
      }, 3000);

      // Send player list to client
      setInterval(() => {
        const players = Object.keys(bot.players);
        socket.emit('players', players);
      }, 5000);
    });

    bot.on('message', (message) => {
      socket.emit('chat', {
        username: 'Server',
        message: message.toString()
      });
    });

    bot.on('chat', (username, message) => {
      socket.emit('chat', { username, message });
    });

    bot.on('end', () => {
      socket.emit('status', 'Disconnected');
      console.log('⛔ Bot disconnected');
    });

    bot.on('error', (err) => {
      console.error('❌ Bot error:', err);
      socket.emit('status', 'Error: ' + err.message);
    });
  });

  socket.on('sendChat', msg => {
    if (bot) bot.chat(msg);
  });
});

http.listen(3000, () => {
  console.log('🚀 Dashboard running: http://localhost:3000');
});